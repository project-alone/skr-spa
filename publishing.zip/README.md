# SK-CarRental

SK 렌터카 프로젝트 진행을 위한 셋팅 및 컴포넌트 작업

## package install

### `npm install`

## project start

### `npm start`
